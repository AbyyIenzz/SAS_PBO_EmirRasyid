package aplikasikasirapp;

public class Barang {
    private String namaBarang;
    private int hargaBarang;
    private int jumlahBeli;

    public Barang(String namaBarang, int hargaBarang, int jumlahBeli) {
        this.namaBarang = namaBarang;
        this.hargaBarang = hargaBarang;
        this.jumlahBeli = jumlahBeli;
    }

    public String getNamaBarang() { return namaBarang; }
    public int getHargaBarang() { return hargaBarang; }
    public int getJumlahBeli() { return jumlahBeli; }

    // POLIMORFISME
    public double hitungDiskon() {
        return 0;
    }

    public double hitungTotal() {
        return (hargaBarang * jumlahBeli) - hitungDiskon();
    }
}
