package aplikasikasirapp;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.Color;

public class AplikasiKasirApp extends JFrame {

    JLabel lblNama = new JLabel("Nama Barang");
    JLabel lblHarga = new JLabel("Harga Barang");
    JLabel lblJumlah = new JLabel("Jumlah Beli");
    JLabel lblKategori = new JLabel("Kategori");

    JTextField txtNama = new JTextField();
    JTextField txtHarga = new JTextField();
    JTextField txtJumlah = new JTextField();

    String[] kategoriBarang = {"Makanan", "Minuman"};
    JComboBox<String> cmbKategori = new JComboBox<>(kategoriBarang);

    JButton btnTambah = new JButton("Tambah");
    JButton btnTotal = new JButton("Hitung Total");

    JTable table;
    DefaultTableModel model;
    JLabel lblTotal = new JLabel("Total Pembayaran : Rp 0");
    double grandTotal = 0;

    public AplikasiKasirApp() {
        setTitle("Aplikasi Kasir Modern - UJIAN SAS");
        setSize(750, 550);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        
        getContentPane().setBackground(new Color(58, 58, 58));

        lblNama.setBounds(20, 20, 120, 25);
        lblNama.setForeground(new Color(224, 224, 224));
        txtNama.setBounds(160, 20, 180, 25);

        lblHarga.setBounds(20, 60, 120, 25);
        lblHarga.setForeground(new Color(224, 224, 224));
        txtHarga.setBounds(160, 60, 180, 25);

        lblJumlah.setBounds(20, 100, 120, 25);
        lblJumlah.setForeground(new Color(224, 224, 224));
        txtJumlah.setBounds(160, 100, 180, 25);

        lblKategori.setBounds(20, 140, 120, 25);
        lblKategori.setForeground(new Color(224, 224, 224));
        cmbKategori.setBounds(160, 140, 180, 25);

        btnTambah.setBounds(20, 190, 140, 30);
        btnTotal.setBounds(180, 190, 140, 30);

        model = new DefaultTableModel();
        model.addColumn("Nama Barang");
        model.addColumn("Kategori");
        model.addColumn("Harga");
        model.addColumn("Jumlah");
        model.addColumn("Diskon");
        model.addColumn("Total");

        table = new JTable(model);
        JScrollPane pane = new JScrollPane(table);
        pane.setBounds(20, 250, 690, 180);

        lblTotal.setBounds(20, 450, 400, 30);
        lblTotal.setForeground(new Color(224, 224, 224));
        lblTotal.setFont(new java.awt.Font("Segoe UI", java.awt.Font.BOLD, 16));

        add(lblNama); add(txtNama);
        add(lblHarga); add(txtHarga);
        add(lblJumlah); add(txtJumlah);
        add(lblKategori); add(cmbKategori);
        add(btnTambah); add(btnTotal);
        add(pane); add(lblTotal);

        btnTambah.addActionListener(e -> tambahTransaksi());
        btnTotal.addActionListener(e -> {
            lblTotal.setText("Total Pembayaran : Rp " + String.format("%,.0f", grandTotal));
        });

        setVisible(true);
    }

    private void tambahTransaksi() {
        try {
            String nama = txtNama.getText();
            int harga = Integer.parseInt(txtHarga.getText());
            int jumlah = Integer.parseInt(txtJumlah.getText());
            String kategori = cmbKategori.getSelectedItem().toString();

            Barang barang;

            if (kategori.equals("Makanan")) {
                barang = new Makanan(nama, harga, jumlah);
            } else {
                barang = new Minuman(nama, harga, jumlah);
            }

            double diskon = barang.hitungDiskon();
            double total = barang.hitungTotal();
            grandTotal += total;

            model.addRow(new Object[]{
                barang.getNamaBarang(),
                kategori,
                barang.getHargaBarang(),
                barang.getJumlahBeli(),
                diskon,
                total
            });

            txtNama.setText("");
            txtHarga.setText("");
            txtJumlah.setText("");

        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Masukkan harga dan jumlah beli dengan angka!", "Format Salah", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        new AplikasiKasirApp();
    }
}
