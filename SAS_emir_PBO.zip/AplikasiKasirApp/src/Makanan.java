package aplikasikasirapp;

public class Makanan extends Barang {
    public Makanan(String namaBarang, int hargaBarang, int jumlahBeli) {
        super(namaBarang, hargaBarang, jumlahBeli);
    }

    // POLIMORFISME Diskon 10%
    @Override
    public double hitungDiskon() {
        return (getHargaBarang() * getJumlahBeli()) * 0.10;
    }
}
