package aplikasikasirapp;

public class Minuman extends Barang {
    public Minuman(String namaBarang, int hargaBarang, int jumlahBeli) {
        super(namaBarang, hargaBarang, jumlahBeli);
    }

    // POLIMORFISME Diskon 5%
    @Override
    public double hitungDiskon() {
        return (getHargaBarang() * getJumlahBeli()) * 0.05;
    }
}
